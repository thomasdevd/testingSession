package StreamsTutorial;

import static org.testng.Assert.assertTrue;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Test1 {
/*	@Test
	public void regular() {
		ArrayList<String> names = new ArrayList<String>();
		names.add("Abijeet");
		names.add("Arun");
		names.add("Don");
		names.add("Anush");
		names.add("sam");
		int count = 0;
		for (int i = 0; i < names.size(); i++) {
			String actual = names.get(i);
			if (actual.startsWith("A")) {
				count++;
			}
		}
		System.out.println(count);*/
	//}

	//@Test

	/*public void streamFilter() {
		ArrayList<String> names = new ArrayList<String>();
		names.add("Abijeet");
		names.add("Arun");
		names.add("Don");
		names.add("Anush");
		names.add("sam");
		
		//there is no life for intermediate operation If there is no terminal operation
		//terminal operation will execute only if intermediate operation (filter) returns true
		//we can create stream
		//how to use filter in stream API
		
		long c = names.stream().filter(s->s.startsWith("A")).count();
		System.out.println(c);
		
		long d = Stream.of("Abijeet","Arun","Don","Anush","sam").filter(s->s.startsWith("A")).count();
		System.out.println(d);
		
		//print all the names length is greater than four Arraylist
		names.stream().filter(y->y.length()>4).forEach(y->System.out.println(y));
		//print all the names of Arraylist
		names.stream().forEach(y->System.out.println(y));
	}
	*/
	/*@Test
	public void streamMap()
	{
		ArrayList<String> names = new ArrayList<String>();
		names.add("Man");
		names.add("Women");
		names.add("Don");
		
		//print the names which has last letter as "�" with uppercase
		Stream.of("Azbijeet","Aruna","Don","Anush","Rama").filter(s->s.endsWith("a")).map(s->s.toUpperCase())
		.forEach(s->System.out.println(s));
		
		//print the names which has first last letter as "�" with uppercase and sorted
		List<String>names1 = Arrays.asList("Azbijeet","Aruna","Don","Anush","Rama");
		names1.stream().filter(s->s.startsWith("A")).sorted().map(s->s.toUpperCase()).forEach(s->System.out.println(s));
		
		//Merging 2 different List
	    Stream<String> newStream = Stream.concat(names.stream(), names1.stream());
	    //valid code commenting because to check Anyway method
	   // newStream.sorted().forEach(s->System.out.println(s));
	   boolean flag = newStream.anyMatch(s->s.equalsIgnoreCase("Don"));
	   System.out.println(flag);
	   Assert.assertTrue(flag);
	    	
	}*/
	
	@Test
	public void streamCollect()
	{
		/*List<String> ls = Stream.of("Azbijeet","Aruna","Don","Anush","Rama").filter(s->s.endsWith("a")).map(s->s.toUpperCase())
		.collect(Collectors.toList());
		System.out.println(ls.get(0));
		*/
		List<Integer>values = Arrays.asList(3,2,2,7,5,1,9,7);
		//print unique number from this array
		//values.stream().distinct().forEach(s->System.out.println(s));
		
		//Output for the below line is: 1,2
		//values.stream().distinct().sorted().limit(2).forEach(s->System.out.println(s));
		
		//sort the array -3rd index -1,2,3,5,7,9
		List<Integer>li = values.stream().distinct().sorted().collect(Collectors.toList());
		System.out.println(li.get(2));
		
	}
}
