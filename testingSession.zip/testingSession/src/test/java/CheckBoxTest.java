
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CheckBoxTest {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.seleniumeasy.com/test/basic-checkbox-demo.html");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		WebElement singlecheckbox = driver.findElement(By.id("isAgeSelected"));

		 singlecheckbox.click();

		WebElement OnSingleCheckBoxSelectionMessage = driver.findElement(By.id("txtAge"));

		if (OnSingleCheckBoxSelectionMessage.isDisplayed()) {

			System.out.println("CheckBox is selected and message displayed correctly");
		}

		else {

			System.out.println("CheckBox is not selected and message displayed incorrectly");
		}

		// *[@id="isAgeSelected"]
		// WebElement language =
		// driver.findElement(By.xpath("//select[@id='searchLanguage']"));
		/*
		 * Select dropDown = new Select(language);
		 *
		 * dropDown.selectByIndex(index);
		 *
		 * List<WebElement> values = driver.findElements(By.tagName("option"));
		 *
		 * System.out.println("Total values inside the language dropdown:" +
		 * values.size());
		 *
		 * for (int i = 0; i < values.size(); i++) {
		 *
		 * if (values.get(i).isSelected()) {
		 *
		 * System.out.println("The selected language is : " + i + " " +
		 * values.get(i).getText()); } }
		 */
		// driver.quit();
	}
}