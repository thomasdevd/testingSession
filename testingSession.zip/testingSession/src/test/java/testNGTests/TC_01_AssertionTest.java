package testNGTests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC_01_AssertionTest {
	public static WebDriver driver;
	
	@BeforeTest
	public static void init() {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/automation-practice-form");
	}
	
	@Test(priority = 1)
	public static void registrationTest() {
		
		String expectedText = "Student Registration Form";
		WebElement headertext = driver.findElement(By.xpath("//h5"));
		String actualText = headertext.getText();
		
		//SoftAssert softAssert = new SoftAssert();
		Assert.assertEquals(actualText, expectedText, "Text Mismatch");	
		System.out.println(actualText);
	}
	
	@Test(priority = 2, dependsOnMethods = "registrationTest")
	public static void loginTest() {
		
		System.out.println("This is login test");
	}
	
	
	@AfterTest
	public static void kill() {
		
		driver.quit();
	}
	
	
}

