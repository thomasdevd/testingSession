import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HandlingTable {
	
	public static void main(String[] args) {
		
	long startTime = System.currentTimeMillis();
	WebDriverManager.chromedriver().setup();
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://www.seleniumeasy.com/test/table-pagination-demo.html");
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	List<WebElement> tabelRows = driver.findElements(By.xpath("//*[@id=\"myTable\"]/tr"));
	System.out.println("total number of rows" +tabelRows.size());
	List<WebElement>tabelCols=driver.findElements(By.xpath("//*[@id=\"myTable\"]/tr/td"));
	System.out.println("total number of colum" +tabelCols.size());
	
	WebElement pageOne = driver.findElement(By.xpath("//*[@id=\"myPager\"]/li[2]/a"));
	WebElement pageTwo = driver.findElement(By.xpath("//*[@id=\"myPager\"]/li[3]/a"));
	WebElement pageThree = driver.findElement(By.xpath("//*[@id=\"myPager\"]/li[4]/a"));
	
	
	for(int i = 1;i<=tabelRows.size();i++)
	{   
		secondloop:
		for(int j = 1;j<=tabelCols.size();j++)
		{
			if(j == 8)
			break secondloop;
		
			pageOne.click();
			WebElement cell1 = driver.findElement(By.xpath("//*[@id=\"myTable\"]/tr["+i+"]/td["+j+"]"));
			System.out.print(cell1.getText() + " ");
			
			pageTwo.click();
			WebElement cell2 = driver.findElement(By.xpath("//*[@id=\"myTable\"]/tr["+i+"]/td["+j+"]"));
			System.out.print(cell2.getText() + " ");
			 
			pageThree.click();
		    WebElement cell3 = driver.findElement(By.xpath("//*[@id=\"myTable\"]/tr["+i+"]/td["+j+"]"));
	        System.out.print(cell3.getText() + " ");	
		}
		System.out.println("");
   }
	

	driver.quit();
	
	long endTime = System.currentTimeMillis();
    long timeTakenInSeconds = (endTime - startTime) / 1000 ;
	
	System.out.println("Time taken to execute this entire program: " +timeTakenInSeconds);
	}	
}
