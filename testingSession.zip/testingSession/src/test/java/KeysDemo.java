import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class KeysDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.get("https://portfolio.rediff.com/portfolio-login");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//input[@id='useremail']")).click();
		
		driver.findElement(By.xpath("//*[@id='queryTop']/div/div[1]/span[1]")).click();

	    // driver.findElement(By.xpath("//*[@id='wrapper']")).click();
	  
		Actions act = new Actions(driver);
		act.sendKeys(Keys.chord(Keys.CONTROL+"A")).perform();
		act.sendKeys(Keys.chord(Keys.CONTROL+"C")).perform();
		
	
		driver.findElement(By.xpath("//input[@id='useremail']")).click();

		act.sendKeys(Keys.chord(Keys.CONTROL+"V")).build().perform();

		// driver.quit();

	}

}
