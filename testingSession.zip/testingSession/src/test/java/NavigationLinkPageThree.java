import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NavigationLinkPageThree {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.seleniumeasy.com/test/table-pagination-demo.html");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		WebElement paginatioLinks = driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div"));
		List<WebElement> links = paginatioLinks.findElements(By.tagName("a"));
		System.out.println("Total number of links: " + links.size());

		for (WebElement link : links) {
			System.out.println("Link is: " + link.getText());
		}

		WebElement pageThree = driver.findElement(By.xpath("//*[@id=\"myPager\"]/li[4]/a"));
		pageThree.click();

		WebElement table = driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/section/div"));
		List<WebElement> tableRow = table.findElements(By.xpath("//tr[@style = 'display: table-row;']"));
		System.out.println("Number of total rows: " + tableRow.size());

		List<WebElement> tableCol = table.findElements(By.xpath("//tbody[@id='myTable']/tr[11]/td"));
		System.out.println("Number of total col: " + tableCol.size());
		first:
		for (int i = 11; i>tableRow.size(); i++) {
	
			for (int j = 1; j <=tableCol.size(); j++) {
				if(i == 14)
				break first;
				WebElement cell = driver.findElement(By.xpath("//tbody[@id='myTable']/tr["+i+"]/td["+j+"]"));
				System.out.print(cell.getText() + " ");
				
			}
			System.out.println("");
			
		}
		WebElement clickONArrowLink = driver.findElement(By.xpath("//*[@id=\"myPager\"]/li[1]/a"));
		clickONArrowLink.click();
		driver.quit();
	}
}