import static org.testng.Assert.fail;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
public class Assignment1 {
	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.seleniumeasy.com/test/table-pagination-demo.html");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		WebElement pageOne = driver.findElement(By.xpath("//*[@id='myPager']/li[2]/a"));
		WebElement pageOneParentTag = driver.findElement(By.xpath("//*[@id='myPager']/li[2]/a/.."));
		WebElement pageTwo = driver.findElement(By.xpath("//*[@id='myPager']/li[3]/a"));
		WebElement pageTwoParentTag = driver.findElement(By.xpath("//*[@id='myPager']/li[3]/a/.."));
		WebElement pageThree = driver.findElement(By.xpath("//*[@id='myPager']/li[4]/a"));
		WebElement pageThreeParentTag = driver.findElement(By.xpath("//*[@id='myPager']/li[4]/a/.."));
		WebElement forwardArrow = driver.findElement(By.xpath("//*[@id='myPager']/li[5]/a"));
		WebElement table1 = driver.findElement(By.xpath("//tbody[@id='myTable']"));
		List<WebElement> tableRow1 = table1.findElements(By.xpath("//tr[@style = 'display: table-row;']"));
		List<WebElement> tableCol1 = table1.findElements(By.xpath("//tbody[@id='myTable']/tr[1]/td"));
		WebElement table2 = driver.findElement(By.xpath("//tbody[@id='myTable']"));
		List<WebElement> tableRow2 = table2.findElements(By.xpath("//tr[@style = 'display: table-row;']"));
		List<WebElement> tableCol2 = table2.findElements(By.xpath("//tbody[@id='myTable']/tr[6]/td"));
		WebElement table3 = driver.findElement(By.xpath("//tbody[@id='myTable']"));
		List<WebElement> tableRow3 = table3.findElements(By.xpath("//tr[@style = 'display: table-row;']"));
		List<WebElement> tableCol3 = table3.findElements(By.xpath("//tbody[@id='myTable']/tr[11]/td"));
		WebElement actualPageHeader = driver.findElement(By.xpath("//h2[contains(text(), 'Pagination')]"));
		String actualPageHeaderMessage = actualPageHeader.getText();
		String expectedPageHeaderMessage = "Table with Pagination Example";
		org.testng.Assert.assertEquals(actualPageHeaderMessage, expectedPageHeaderMessage,
				"Not on table pagination page");
		//System.out.println(pageOneParentTag.getAttribute("class"));
		if (pageOneParentTag.getAttribute("class").equalsIgnoreCase("active"))
		
		{
			//System.out.println("Number of total rows: " + tableRow1.size());
			//System.out.println("Number of total cols: " + tableCol1.size());
			for (int i = 1; i <= tableRow1.size(); i++) {
				for (int j = 1; j <= tableCol1.size(); j++) {
					WebElement cell = driver
							.findElement(By.xpath("//tbody[@id='myTable']/tr[" + i + "]/td[" + j + "]"));
					System.out.print(cell.getText() + " ");
				}
				System.out.println("");
				System.out.println("");
			}
		}
		else {
			org.testng.Assert.fail();
		}
		pageTwo.click();
		//System.out.println(pageTwoParentTag.getAttribute("class"));
		if (pageTwoParentTag.getAttribute("class").equalsIgnoreCase("active")) {
			//System.out.println("Number of total rows: " + tableRow2.size());
			//System.out.println("Number of total cols: " + tableCol2.size());
			for (int i = 6; i <= (tableRow2.size() + 5); i++) {
				for (int j = 1; j <= tableCol2.size(); j++) {
					WebElement cell = driver
							.findElement(By.xpath("//tbody[@id='myTable']/tr[" + i + "]/td[" + j + "]"));
					System.out.print(cell.getText() + " ");
				}
				System.out.println("");
				System.out.println("");
			}
		}
		else {
			org.testng.Assert.fail();
		}
		pageThree.click();
		//System.out.println("Number of total rows: " + tableRow3.size());
		//System.out.println("Number of total cols: " + tableCol3.size());
		//System.out.println(pageThreeParentTag.getAttribute("class"));
		if (pageThreeParentTag.getAttribute("class").equalsIgnoreCase("active")) {
			secondloop:
			for (int i = 11; i <= (tableRow3.size() + 10); i++) {
				
				if(i==14)
					break secondloop;
				
				for (int j = 1; j <= tableCol3.size(); j++) {
					
					WebElement cell = driver.findElement(By.xpath("//tbody[@id='myTable']/tr[" + i + "]/td[" + j + "]"));
					System.out.print(cell.getText() + " ");
				}
				System.out.println("");
				System.out.println("");
				
			}
			
		}
		else {
			org.testng.Assert.fail();
		}
		driver.quit();
		long endTime = System.currentTimeMillis();
		long timeTakenInSeconds = (endTime - startTime) / 1000;
		System.out.println("Time taken to execute this entire program: " + timeTakenInSeconds);
	}
}