import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FirstProgram {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://way2automation.com/way2auto_jquery/index.php");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		String title = driver.getTitle();
		System.out.println("Title of the page is: " + title);
		System.out.println("Length of the title is : " + title.length());
		WebElement registrationForm = driver.findElement(By.xpath("//div[@id=\"load_box\"]//h3"));
		WebElement name = driver.findElement(By.xpath("//div[@id='load_box']//input[@name='name']"));
		WebElement phone = driver.findElement(By.xpath("//input[@name='phone']"));
		WebElement email = driver.findElement(By.xpath("//input[@name='email']"));
		WebElement country = driver.findElement(By.xpath("//select[@name = 'country']"));
		WebElement city = driver.findElement(By.xpath("//input[@name='city']"));
		WebElement username = driver.findElement(By.xpath("//div[@id='load_box']//input[@name='username']"));
		WebElement password = driver.findElement(By.xpath("//div[@id='load_box']//input[@name='password']"));
		WebElement submitButton = driver.findElement(By.xpath("//div[@id='load_box']//input[@type='submit']"));
		
		WebElement successfullRegistrationMessage = driver.findElement(By.xpath("//p[@id='alert']"));
		if (registrationForm.isDisplayed()) {
			System.out.println("Registration Form found");
			name.sendKeys("Abhishek");
			
			phone.sendKeys("8880591539");
			
			email.sendKeys("abhi2010.verma@gmail.com");
			Select dropdown = new Select(country);
			dropdown.selectByVisibleText("India");
			city.sendKeys("Bangalore");
			
			WebDriverWait waitExp  = new WebDriverWait(driver, 10000);
			
			waitExp.until(ExpectedConditions.visibilityOf(username)).sendKeys("AbhiThomasTest");
			
			waitExp.until(ExpectedConditions.visibilityOf(password)).sendKeys("Abcdef1$");
			
			waitExp.until(ExpectedConditions.visibilityOf(submitButton)).click();
			
			if(waitExp.until(ExpectedConditions.visibilityOf(successfullRegistrationMessage)).isDisplayed()) {
				
				System.out.println("User successfully registered");
			}
		}
		
		driver.quit();
	}
}