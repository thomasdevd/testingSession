import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
public class CheckBoxTest1 {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.seleniumeasy.com/test/basic-checkbox-demo.html");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		WebElement checkboxBlock = driver.findElement(By.xpath("//div[@id='easycont']/div/div[2]/div[2]/div[2]"));
		List<WebElement> checkBoxes = checkboxBlock.findElements(By.className("cb1-element"));
		for (WebElement checkbox : checkBoxes) {
			checkbox.click();
			if (checkbox.isSelected()) {
				System.out.println("checkbox selected");
			}
			else {
				System.out.println("checkbox not selected");
			}
		}
		driver.quit();
	}
}