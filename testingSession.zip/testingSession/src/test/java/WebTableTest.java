import java.util.List;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
public class WebTableTest {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.seleniumeasy.com/test/table-pagination-demo.html");
		
		WebElement actualPageHeader = driver.findElement(By.xpath("//h2[contains(text(), 'Pagination')]"));
		String actualPageHeaderMessage = actualPageHeader.getText();
		
		String expectedPageHeaderMessage = "Table with Pagination Example";
     
		org.testng.Assert.assertEquals(actualPageHeaderMessage, expectedPageHeaderMessage, "Not on table pagination page");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		WebElement table = driver.findElement(By.xpath("//tbody[@id='myTable']"));
		
		List<WebElement> tableRow = table.findElements(By.xpath("//tr[@style = 'display: table-row;']"));
		
		System.out.println("Number of total rows: " +tableRow.size());	
		
		List<WebElement> tableCol = table.findElements(By.xpath("//tbody[@id='myTable']/tr[1]/td"));
		
		System.out.println("Number of total cols: " +tableCol.size());
		
		for(int i=1; i<=tableRow.size(); i++) {
			
			for(int j=1; j<=tableCol.size(); j++) {
				
				WebElement cell = driver.findElement(By.xpath("//tbody[@id='myTable']/tr["+i+"]/td["+j+"]"));	
				System.out.print(cell.getText() + " ");
			}
			System.out.println("");
			System.out.println("");
		}
		
		/*
		 * for(int i=1; i<=5;i++) {
		 *
		 * for(int j=1; j<=7;j++) {
		 *
		 * WebElement cell =
		 * driver.findElement(By.xpath("//tbody[@id='myTable']/tr["+i+"]/td["+j+"]"));
		 *
		 * //tbody[@id='myTable']/tr[1]/td[1]") //tbody[@id='myTable']/tr[1]/td[2]")
		 * //tbody[@id='myTable']/tr[1]/td[3]") //tbody[@id='myTable']/tr[1]/td[4]")
		 * //tbody[@id='myTable']/tr[1]/td[5]") //tbody[@id='myTable']/tr[1]/td[6]")
		 * //tbody[@id='myTable']/tr[1]/td[7]")
		 *
		 * //tbody[@id='myTable']/tr[2]/td[1]") //tbody[@id='myTable']/tr[2]/td[2]")
		 * //tbody[@id='myTable']/tr[2]/td[3]") //tbody[@id='myTable']/tr[2]/td[4]")
		 * //tbody[@id='myTable']/tr[2]/td[5]") //tbody[@id='myTable']/tr[2]/td[6]")
		 * //tbody[@id='myTable']/tr[2]/td[7]") } }
		 */
		
		
		driver.quit();
	}
}