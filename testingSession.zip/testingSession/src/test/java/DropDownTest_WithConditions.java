import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import io.github.bonigarcia.wdm.WebDriverManager;
public class DropDownTest_WithConditions {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.wikipedia.org/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Random rand = new Random();
		
		int index = 0 + rand.nextInt(69);
		
		System.out.println("The index value to be selected: " +index);
		WebElement language = driver.findElement(By.xpath("//select[@id='searchLanguage']"));
		Select dropDown = new Select(language);
		dropDown.selectByIndex(index);
		List<WebElement> values = driver.findElements(By.tagName("option"));
		System.out.println("Total values inside the language dropdown:" + values.size());
		for (int i = 0; i < values.size(); i++) {
			
			if (values.get(i).isSelected()) {
				System.out.println("The selected language is : " + i + " " + values.get(i).getText());
			}
		}
		driver.quit();
	}
}