package PractiseTest;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AddMultipleItemToCartUsingGenericMethod {
	public static void main(String[] args) 
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("https://rahulshettyacademy.com/seleniumPractise/");
		String[] productItems = {"Cauliflower","Brocolli","Cucumber"};

		addItem(driver,productItems);
		driver.findElement(By.xpath("//img[@alt='Cart']")).click();
		driver.findElement(By.xpath("//button[text()='PROCEED TO CHECKOUT']")).click();
		driver.findElement(By.cssSelector(".promoCode")).sendKeys("rahulshettyacademy");
		driver.findElement(By.cssSelector(".promoBtn")).click();
		
		WebDriverWait w = new WebDriverWait(driver, 5);
		w.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector("span.promoInfo")));
		System.out.println(driver.findElement(By.cssSelector("span.promoInfo")).getText());
	}


	public static void addItem(WebDriver driver,String[] productItems)
	{
	int j=0;
    List<WebElement> productNames=driver.findElements(By.xpath("//h4[@class='product-name']"));
 
    
   for(int i=0;i<productNames.size();i++)
    {
	 List ProductItemsList = Arrays.asList(productItems);
	 
	 String[] names = productNames.get(i).getText().split("-");
	 String foramtedItem = names[0].trim();
	System.out.println(foramtedItem);
	
	if(ProductItemsList.contains(foramtedItem))
    	{
		j++;
		  //driver.findElements(By.xpath("//button[@type='button']")).get(i).click();
		  driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click();
		  if(j==productItems.length)
		  {
			  break;
		  }
		
    	}
    }
	
	}
}
