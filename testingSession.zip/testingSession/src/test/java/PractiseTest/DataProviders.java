package PractiseTest;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviders {
	
	@Test(dataProvider="customerDP")
	public void login(String Username,String password)
	{
		System.out.println(Username);
		System.out.println(password);
	}
	@DataProvider(name="customerDP")
	public Object[][] getdemo()
	{
		
		 Object[][] data = new  Object[2][2];
		data[0][0]= "thomas@123";
		data[0][1]= "password";	
		
		data[1][0]= "thomas@12345";
		data[1][1]= "password123";	
		
		return data;
		
	}

}
