package PractiseTest;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class calendar {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://www.path2usa.com/travel-companions");
		driver.findElement(By.xpath("//input[@id='travel_date']")).click();
		
		WebElement monthName = driver.findElement(By.xpath("//div[@Class='datepicker-days']/table/thead/tr[1]/th[2]"));
		while(!monthName.getText().contains("August"))
		{
			driver.findElement(By.xpath("//div[@Class='datepicker-days']/table/thead/tr[1]/th[3]")).click();
		}
		
		/*
		 * disadvantage every time we need to change the xpath for the below line
		 * driver.findElement(By.xpath("//tr[5]/td[7]")).click();
		 */
/*
		 List<WebElement> rows =
		 driver.findElements(By.xpath("//div[@Class='datepicker-days']/table/tbody/tr/td
*/		// Solution:Find the common xpath
		List<WebElement> dates = driver.findElements(By.className("day"));

		for (int i = 0; i < dates.size(); i++) {
			String text = dates.get(i).getText();
			if (text.equalsIgnoreCase("20")) {
				dates.get(i).click();
				break;
			}

		}
	}
}
