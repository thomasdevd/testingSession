import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DyanmicDropDown {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.findElement(By.id(("ctl00_mainContent_ddl_originStation1_CTXT"))).click();
       
      //a[@value='MAA']: Two matching node
       
        driver.findElement(By.xpath("//a[@value='BLR']")).click(); 
        //driver.findElement(By.xpath("(//a[@value='MAA'])[2]")).click();
        /*           (OR)
        Parent child relationship xpath*/
        driver.findElement(By.xpath("//div[@id='glsctl00_mainContent_ddl_destinationStation1_CTNR']//a[@value='MAA']")).click();
        driver.quit();
        
        
       /* Error Message: element not interactable
        driver.findElement(By.xpath("//a[@value='MAA']")).click();
        Error Message: no such element
        driver.findElement(By.xpath("//a[@value='MAA1234']")).click();*/
        
        
        
      
	}
}