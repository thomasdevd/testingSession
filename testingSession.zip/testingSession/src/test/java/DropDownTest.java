
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DropDownTest {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.wikipedia.org/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		String title = driver.getTitle();
		System.out.println("Title of the page is: " + title);
		System.out.println("Length of the title is : " + title.length());
		WebElement language = driver.findElement(By.xpath("//select[@id='searchLanguage']"));
		Select dropDown = new Select(language);
		dropDown.selectByVisibleText("English");
		List<WebElement> values = driver.findElements(By.tagName("option"));
		System.out.println("First option text is: " + values.get(0).getText());
		System.out.println("Total values inside the language dropdown:" + values.size());
	/*	for (int i = 0; i < values.size(); i++) {
			System.out.println("Language text is: " + values.get(i).getText());
		}*/
		for (WebElement value : values) {
			System.out.println("Language text is: " + value.getText());
		}
		driver.quit();
	}
}
