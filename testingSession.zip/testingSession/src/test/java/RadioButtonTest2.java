import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
public class RadioButtonTest2 {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.seleniumeasy.com/test/basic-radiobutton-demo.html");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		WebElement maleRadioButton = driver.findElement(By.xpath("//div[1]/div[2]/label[1]/input[@value='Male']"));
		
		WebElement femaleRadioButton = driver.findElement(By.xpath("//div[1]/div[2]/label[2]/input[@value='Female']"));
		
		femaleRadioButton.click();
		
		WebElement buttonCheck = driver.findElement(By.xpath("//button[@id='buttoncheck']"));
		
		buttonCheck.click();
		
		WebElement onButtonCheckMessage = driver.findElement(By.xpath("//p[@class = 'radiobutton']"));
		
		String actualTextMessage = onButtonCheckMessage.getText();
		
		String expectedTextMessage = "Radio button 'Female$' is checked";
		
		//org.testng.Assert.assertEquals(actualTextMessage, expectedTextMessage, "Message does not match");
		
		System.out.println("The displayed message is: " +actualTextMessage);
		
		if(onButtonCheckMessage.isDisplayed()) {
			
			System.out.println("Message displayed correctly");
		}
		
		else {
			
			System.out.println("No message displayed");
		}
		
		
		driver.quit();
	}
}