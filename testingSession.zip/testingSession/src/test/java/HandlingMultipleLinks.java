import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
public class HandlingMultipleLinks {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.wikipedia.org/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		String title = driver.getTitle();
		System.out.println("Title of the page is: " + title);
		System.out.println("Length of the title is : " + title.length());
		List<WebElement> links = driver.findElements(By.tagName("a"));
		
		System.out.println("Total number of links: "+links.size());
		
		for(WebElement link:links) {
			
			System.out.println("Link is: "+link.getText());
		}
		driver.quit();
	}
}