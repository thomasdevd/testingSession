import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ActionDemo2 {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://www.amazon.com/");
		Actions a = new Actions(driver);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		System.out.println(driver.getTitle());
		WebElement move = driver.findElement(By.cssSelector("span[id*='nav-link']"));
		 a.moveToElement(move).build().perform();
	///	WebElement searchBox=driver.findElement(By.id("twotabsearchtextbox"));
		//a.keyDown(Keys.SHIFT).sendKeys(searchBox, "Hello").build().perform();
		//a.moveToElement(searchBox).click().keyUp(Keys.SHIFT).sendKeys("hello").doubleClick().build().perform();
	   
	     
	    //Right click method
	    a.moveToElement(move).contextClick().build().perform();
	   
	    
	}
	
}
