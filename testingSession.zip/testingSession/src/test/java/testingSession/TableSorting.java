package testingSession;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TableSorting{
	public static void main(String[] args)
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
		// click on column
		driver.findElement(By.xpath("//tr//th[1]")).click();
		
		// capture all webelements into list
		List<WebElement> veggies = driver.findElements(By.xpath("//tr//td[1]"));
		
		// capture text of all webelements into new(original) list
		List<String> orginalList = veggies.stream().map(s->s.getText()).collect(Collectors.toList());
		System.out.println(orginalList);
		
		// sort on the original list of step 3 -> sorted list
	    List<String> sortedList = orginalList.stream().sorted().collect(Collectors.toList());
	    System.out.println(sortedList);
		
	    // compare original list vs sorted list
	    Assert.assertTrue(orginalList.equals(sortedList));
	    
	 // scan the name column with getText ->Beans->print the price of the Beans
	    
	   List<String> price = veggies.stream().filter(s->s.getText().contains("Beans"))
	   .map(s->getPriceVeggie(s)).collect(Collectors.toList());
	   price.forEach(a->System.out.println(a));
	   
	 //  need to reslove the error 
	   
	}
	 private static String getPriceVeggie(WebElement s)
     {

		String pricevalue = s.findElement(By.xpath("following-sibling::td[1]")).getText();
		return pricevalue;

		}
	
  }
