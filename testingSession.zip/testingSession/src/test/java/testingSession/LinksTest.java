package testingSession;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LinksTest {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://qaclickacademy.com/practice.php");
		
        //1. Give me the count of links on the page.
		//2. Count of footer section-
		
		System.out.println(driver.findElements(By.tagName("a")).size());
		WebElement footerSection = driver.findElement(By.xpath("//div[@id ='gf-BIG']"));
	    System.out.println(footerSection.findElements(By.tagName("a")).size());
	    
	    
	    WebElement coloumndriver = driver.findElement(By.xpath("//table/tbody/tr/td[1]/ul"));
	    System.out.println(coloumndriver.findElements(By.tagName("a")).size());
	    
	   int links= coloumndriver.findElements(By.tagName("a")).size();
	  //4- click on each link in the coloumn and check if the pages are opening-
	    for(int i=0;i<links;i++)
	    {

			String clickonlinkTab=Keys.chord(Keys.CONTROL,Keys.ENTER);
			coloumndriver.findElements(By.tagName("a")).get(i).sendKeys(clickonlinkTab);
			
			
	    }
	  //opens all the tab
	    Set<String> newTabwindows = driver.getWindowHandles();
	     Iterator<String> i1=newTabwindows.iterator();
	     while(i1.hasNext())
	     {
	    	 driver.switchTo().window(i1.next());
	    	 System.out.println(driver.getTitle());
	     }
	}
}
