package testingSession;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Ecommerce {
	public static void main(String[] args) {
	WebDriverManager.chromedriver().setup();
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://rahulshettyacademy.com/seleniumPractise/");
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	
	//to handle only one item
	/*driver.findElement(By.xpath("(//button[text()='ADD TO CART'])[1]")).click();
	System.out.println(driver.findElement(By.xpath("//h4[text()='Brocolli - 1 Kg']")).getText());*/
	String[] ProductItems= {"Brocolli - 1 Kg","Cauliflower - 1 Kg","Cucumber - 1 Kg"};
	
	List<WebElement>productName = driver.findElements(By.xpath("//h4[@class='product-name']"));
	System.out.println("Total list of product names: " +productName.size());
	
	
	 
	for(int i=0;i<productName.size();i++)
	{
   
	String name = productName.get(i).getText();
	
	/*convert array into array list for easy search
    check whether name you extracted is present in arrayList or not- 
	*/
	 List ProductItemsList = Arrays.asList(ProductItems);
		if(ProductItemsList.contains(name))
			
		{   //click on Add to cart
			driver.findElements(By.xpath("//button[text()='ADD TO CART']")).get(i).click();
			
		}
	}
	
	
	
}
}
