package testingSession;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class calendar {
	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://www.path2usa.com/travel-companions");
		//driver.findElementByXPath(".//*[@id='travel_date']").click(); 
		driver.findElement(By.xpath("//input[@id='travel_date']")).click();
		
		WebElement monthName =driver.findElement(By.xpath("//div[@class='datepicker-days']/table/thead/tr[1]/th[2]"));
		while(!monthName.getText().contains("July"))
		{
			driver.findElement(By.xpath("//div[@class='datepicker-days']/table/thead/tr[1]/th[3]")).click();
		}
		
		
		List<WebElement> dates = driver.findElements(By.className("day"));
		int count=driver.findElements(By.className("day")).size();
		
		for(int i=0;i<count;i++)
		{
			String text = dates.get(i).getText();
		//	System.out.println("number of days in each month is : " +text );
		//	String text=driver.findElements(By.className("day")).get(i).getText();
		if(text.equalsIgnoreCase("21"))
	
			{
				
				//driver.findElements(By.className("day")).get(i).click();
				
				dates.get(i).click();
				break;
			}
		}
		
		
		
	}
}
