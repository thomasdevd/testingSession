package testingSession;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebTableExample {
	public static void main(String[] args) {
	WebDriverManager.chromedriver().setup();
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	driver.get("https://money.rediff.com/index.html");
    driver.findElement(By.xpath("//div[@id='div_bse_gainer']/p/a/img")).click();
   /* table[@class='dataTable']-complete table
    Write below in the Xpath field below and hit enter, you will see all the rows and columns get highlighted 
    table[@class='dataTable']/tbody/tr/td*/
    
  //Below xpath would highlight 4th cell of 3rd row
    /*String cellData=driver.findElement(By.xpath("//table[@class='dataTable']/tbody/tr[3]/td[4]")).getText();
    System.out.println(cellData);*/
    
    /*Below xpath would highlight entire 3rd row
    table[@class='dataTable']/tbody/tr[3]------entire third row
    
    Below xpath would highlight all the cells of 3rd row
    table[@class='dataTable']/tbody/tr[3]/td--------each cell of third row
    
    Similarly below xpath represents all the rows
    table[@class='dataTable']/tbody/tr--------all the rows*/
    
    String companyName = "Hero MotoCorp";
    List<WebElement> companyNames = driver.findElements(By.xpath("// table[@class='dataTable']/tbody/tr/td[1]"));
    List<WebElement> currentPrices = driver.findElements(By.xpath("// table[@class='dataTable']/tbody/tr/td[4]"));
    
    for(int i=0;i<companyNames.size();i++)
    {
    	if(companyName.equals(companyNames.get(i).getText()))
    	System.out.println(companyNames.get(i).getText() + "----------------------" + currentPrices.get(i).getText());
    }
    
    driver.quit();
    
	}

}
