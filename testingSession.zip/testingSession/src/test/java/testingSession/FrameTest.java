package testingSession;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FrameTest {
	public static void main(String[] args) {
	WebDriverManager.chromedriver().setup();
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://jqueryui.com/droppable/");
    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    
    //How to find the number of frames in the given webpage
    System.out.println(driver.findElements(By.tagName("iframe")).size());
    //driver.switchTo().frame(0);
    driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class ='demo-frame']")));
    Actions a = new Actions(driver);
    WebElement src = driver.findElement(By.id("draggable"));
    WebElement tar = driver.findElement(By.id("droppable"));
    a.dragAndDrop(src, tar).build().perform();
    driver.switchTo().defaultContent();
    
	}
}
