package testingSession;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CookiesTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		/*below scenario when provide the sessionkey
		click on any link
		login page- verify login URl*/
		driver.manage().deleteCookieNamed("sesssionKey");
		driver.get("https://www.amazon.com/");
	}

}
