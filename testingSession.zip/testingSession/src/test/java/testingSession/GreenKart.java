package testingSession;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import net.bytebuddy.implementation.bytecode.Addition;

public class GreenKart {
	public static void main(String[] args)
	{
		
		   //The moto of the test case to create a Generic method
			WebDriverManager.chromedriver().setup();
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://rahulshettyacademy.com/seleniumPractise/");
			//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

			String[] ProductItems = { "Brocolli", "Cauliflower", "Cucumber" };
			addItems(driver,ProductItems);
			driver.findElement(By.xpath("//img[@alt='Cart']")).click();
			driver.findElement(By.xpath("//button[text()='PROCEED TO CHECKOUT']")).click();
	        
	}    
            //Generic Method
			public static void addItems(WebDriver driver,String[] ProductItems)
			{
			int j=0;
	        List<WebElement> productName = driver.findElements(By.xpath("//h4[@class='product-name']"));
			for (int i = 0; i < productName.size(); i++) 
			{

				String[] name = productName.get(i).getText().split("-");
				String foramtedItem =name[0].trim();
				System.out.println(foramtedItem);

			
				List ProductItemsList = Arrays.asList(ProductItems);
				
				if (ProductItemsList.contains(foramtedItem)) 
				{ 
					j++;
					// click on Add to cart
					driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click();
					if (j == ProductItems.length)
					{
						break;
					}

				}
			}

		}
	}